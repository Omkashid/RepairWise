
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAX_ITEMS 20

// ==========================================
// STRUCTURES
// ==========================================

struct Device {

    char device[30];
    char model[30];
    char problem[50];
    char part[50];
    int repairability;

};

struct Part {

    char device[30];
    char part[50];
    char seller[50];
    int price;

};

struct Shop {

    char name[50];
    char location[30];
    float distance;
    char service[50];

};


// ==========================================
// CASE-INSENSITIVE STRING COMPARISON
// ==========================================

int equalsIgnoreCase(char a[], char b[]) {

    int i = 0;

    while (a[i] != '\0' && b[i] != '\0') {

        if (
            tolower((unsigned char)a[i]) !=
            tolower((unsigned char)b[i])
        ) {

            return 0;

        }

        i++;

    }

    return a[i] == '\0' && b[i] == '\0';

}


// ==========================================
// CASE-INSENSITIVE SEARCH
// ==========================================

int containsIgnoreCase(char text[], char keyword[]) {

    int textLength = strlen(text);
    int keywordLength = strlen(keyword);

    if (keywordLength == 0) {

        return 1;

    }

    if (keywordLength > textLength) {

        return 0;

    }

    for (
        int i = 0;
        i <= textLength - keywordLength;
        i++
    ) {

        int match = 1;

        for (
            int j = 0;
            j < keywordLength;
            j++
        ) {

            if (
                tolower((unsigned char)text[i + j]) !=
                tolower((unsigned char)keyword[j])
            ) {

                match = 0;

                break;

            }

        }

        if (match) {

            return 1;

        }

    }

    return 0;

}


// ==========================================
// SEARCHING ALGORITHM
// ==========================================

int searchDevice(
    struct Device devices[],
    int count,
    char device[],
    char model[],
    char keyword[]
) {

    for (int i = 0; i < count; i++) {

        if (
            equalsIgnoreCase(
                devices[i].device,
                device
            )

            &&

            equalsIgnoreCase(
                devices[i].model,
                model
            )

            &&

            containsIgnoreCase(
                devices[i].problem,
                keyword
            )
        ) {

            return i;

        }

    }

    return -1;

}


// ==========================================
// SORT PARTS BY PRICE
// BUBBLE SORT
// ==========================================

void sortParts(
    struct Part parts[],
    int count
) {

    for (
        int i = 0;
        i < count - 1;
        i++
    ) {

        for (
            int j = 0;
            j < count - i - 1;
            j++
        ) {

            if (
                parts[j].price >
                parts[j + 1].price
            ) {

                struct Part temp =
                    parts[j];

                parts[j] =
                    parts[j + 1];

                parts[j + 1] =
                    temp;

            }

        }

    }

}


// ==========================================
// SORT SHOPS BY DISTANCE
// BUBBLE SORT
// ==========================================

void sortShops(
    struct Shop shops[],
    int count
) {

    for (
        int i = 0;
        i < count - 1;
        i++
    ) {

        for (
            int j = 0;
            j < count - i - 1;
            j++
        ) {

            if (
                shops[j].distance >
                shops[j + 1].distance
            ) {

                struct Shop temp =
                    shops[j];

                shops[j] =
                    shops[j + 1];

                shops[j + 1] =
                    temp;

            }

        }

    }

}


// ==========================================
// MAIN PROGRAM
// ==========================================

int main() {


    // ======================================
    // DEVICE DATABASE
    // ======================================

    struct Device devices[] = {

        {
            "Smartphone",
            "iPhone",
            "Screen Black",
            "Display Assembly",
            78
        },

        {
            "Smartphone",
            "iPhone",
            "Not Charging",
            "Charging Port",
            82
        },

        {
            "Smartphone",
            "iPhone",
            "Battery Draining",
            "Battery",
            75
        },

        {
            "Smartphone",
            "iPhone",
            "Speaker Not Working",
            "Speaker Module",
            85
        },

        {
            "Smartphone",
            "iPhone",
            "Camera Not Working",
            "Camera Module",
            70
        },

        {
            "Smartphone",
            "Samsung Galaxy",
            "Screen Black",
            "Display Assembly",
            80
        },

        {
            "Smartphone",
            "Samsung Galaxy",
            "Not Charging",
            "Charging Port",
            84
        },

        {
            "Smartphone",
            "Samsung Galaxy",
            "Battery Draining",
            "Battery",
            77
        },

        {
            "Laptop",
            "Dell",
            "Screen Not Working",
            "Laptop Display",
            72
        },

        {
            "Laptop",
            "Dell",
            "Battery Not Charging",
            "Laptop Battery",
            68
        },

        {
            "Laptop",
            "Dell",
            "Keyboard Not Working",
            "Keyboard",
            80
        },

        {
            "Laptop",
            "HP",
            "Screen Not Working",
            "Laptop Display",
            74
        },

        {
            "Laptop",
            "HP",
            "Battery Not Charging",
            "Laptop Battery",
            70
        },

        {
            "Laptop",
            "HP",
            "Keyboard Not Working",
            "Keyboard",
            81
        }

    };


    int deviceCount =
        sizeof(devices) /
        sizeof(devices[0]);


    // ======================================
    // SPARE PART DATABASE
    // ======================================

    struct Part parts[] = {

        {
            "Smartphone",
            "Display Assembly",
            "Tech Spare Store",
            3200
        },

        {
            "Smartphone",
            "Display Assembly",
            "Electro World",
            3800
        },

        {
            "Smartphone",
            "Display Assembly",
            "Mobile Parts Hub",
            4500
        },

        {
            "Smartphone",
            "Charging Port",
            "Tech Spare Store",
            700
        },

        {
            "Smartphone",
            "Charging Port",
            "Electro World",
            850
        },

        {
            "Smartphone",
            "Battery",
            "Mobile Parts Hub",
            1200
        },

        {
            "Smartphone",
            "Battery",
            "Tech Spare Store",
            1450
        },

        {
            "Smartphone",
            "Speaker Module",
            "Electro World",
            600
        },

        {
            "Smartphone",
            "Camera Module",
            "Mobile Parts Hub",
            1800
        },

        {
            "Laptop",
            "Laptop Display",
            "Computer Spare Hub",
            4500
        },

        {
            "Laptop",
            "Laptop Display",
            "Laptop Parts Store",
            5200
        },

        {
            "Laptop",
            "Laptop Battery",
            "Computer Spare Hub",
            2500
        },

        {
            "Laptop",
            "Keyboard",
            "Laptop Parts Store",
            1800
        }

    };


    int partCount =
        sizeof(parts) /
        sizeof(parts[0]);


    // ======================================
    // REPAIR SHOP DATABASE
    // ======================================

    struct Shop shops[] = {

        {
            "Mobile Care Center",
            "Ravet",
            1.5,
            "Smartphone Repair"
        },

        {
            "ABC Mobile Repair",
            "Pimpri",
            2.1,
            "Smartphone Repair"
        },

        {
            "TechFix Electronics",
            "Chinchwad",
            3.4,
            "Smartphone Repair"
        },

        {
            "Laptop Care",
            "Pimpri",
            2.8,
            "Laptop Repair"
        },

        {
            "Computer Service Center",
            "Chinchwad",
            4.2,
            "Laptop Repair"
        }

    };


    int shopCount =
        sizeof(shops) /
        sizeof(shops[0]);


    // ======================================
    // USER INPUT
    // ======================================

    char device[30];
    char model[30];
    char keyword[50];


    printf("\n");
    printf("========================================\n");
    printf("     ELECTRONIC REPAIR ASSISTANT\n");
    printf("========================================\n");


    printf("\nEnter Device: ");

    fgets(
        device,
        sizeof(device),
        stdin
    );

    device[
        strcspn(device, "\n")
    ] = '\0';


    printf("Enter Model: ");

    fgets(
        model,
        sizeof(model),
        stdin
    );

    model[
        strcspn(model, "\n")
    ] = '\0';


    printf("Enter Problem Keyword: ");

    fgets(
        keyword,
        sizeof(keyword),
        stdin
    );

    keyword[
        strcspn(keyword, "\n")
    ] = '\0';


    // ======================================
    // SEARCH DEVICE
    // ======================================

    int result =
        searchDevice(
            devices,
            deviceCount,
            device,
            model,
            keyword
        );


    if (result == -1) {

        printf(
            "\nNo matching problem found.\n"
        );

        printf(
            "\nTry examples such as:\n"
        );

        printf(
            "screen black\n"
        );

        printf(
            "not charging\n"
        );

        printf(
            "battery draining\n"
        );

        printf(
            "keyboard not working\n"
        );

        return 0;

    }


    // ======================================
    // DISPLAY DIAGNOSIS
    // ======================================

    printf(
        "\n========================================\n"
    );

    printf(
        "           ANALYSIS RESULT\n"
    );

    printf(
        "========================================\n"
    );


    printf(
        "\nDevice: %s",
        devices[result].device
    );


    printf(
        "\nModel: %s",
        devices[result].model
    );


    printf(
        "\nPossible Issue: %s",
        devices[result].problem
    );


    printf(
        "\nPossible Faulty Part: %s",
        devices[result].part
    );


    printf(
        "\nRepairability Score: %d/100",
        devices[result].repairability
    );


    // ======================================
    // FILTER PARTS
    // ======================================

    struct Part matchingParts[MAX_ITEMS];

    int matchingPartCount = 0;


    for (
        int i = 0;
        i < partCount;
        i++
    ) {

        if (
            equalsIgnoreCase(
                parts[i].device,
                devices[result].device
            )

            &&

            equalsIgnoreCase(
                parts[i].part,
                devices[result].part
            )
        ) {

            matchingParts[
                matchingPartCount
            ] = parts[i];

            matchingPartCount++;

        }

    }


    // ======================================
    // SORT PARTS
    // ======================================

    sortParts(
        matchingParts,
        matchingPartCount
    );


    // ======================================
    // DISPLAY SPARE PARTS
    // ======================================

    printf(
        "\n\n========================================\n"
    );

    printf(
        "           SPARE PARTS\n"
    );

    printf(
        "========================================\n"
    );


    for (
        int i = 0;
        i < matchingPartCount;
        i++
    ) {

        printf(
            "\n%d. %s | Rs.%d | %s",
            i + 1,
            matchingParts[i].seller,
            matchingParts[i].price,
            matchingParts[i].part
        );

    }


    // ======================================
    // FILTER SHOPS
    // ======================================

    struct Shop matchingShops[MAX_ITEMS];

    int matchingShopCount = 0;


    for (
        int i = 0;
        i < shopCount;
        i++
    ) {

        if (
            strstr(
                shops[i].service,
                devices[result].device
            ) != NULL
        ) {

            matchingShops[
                matchingShopCount
            ] = shops[i];

            matchingShopCount++;

        }

    }


    // ======================================
    // SORT SHOPS
    // ======================================

    sortShops(
        matchingShops,
        matchingShopCount
    );


    // ======================================
    // DISPLAY REPAIR SHOPS
    // ======================================

    printf(
        "\n\n========================================\n"
    );

    printf(
        "          REPAIR SHOPS\n"
    );

    printf(
        "========================================\n"
    );


    for (
        int i = 0;
        i < matchingShopCount;
        i++
    ) {

        printf(
            "\n%d. %s | %s | %.1f km",
            i + 1,
            matchingShops[i].name,
            matchingShops[i].location,
            matchingShops[i].distance
        );

    }


    // ======================================
    // DSA SUMMARY
    // ======================================

    printf(
        "\n\n========================================\n"
    );

    printf(
        "             DSA USED\n"
    );

    printf(
        "========================================\n"
    );


    printf(
        "\n1. Arrays"
    );

    printf(
        "\n2. Searching"
    );

    printf(
        "\n3. Filtering"
    );

    printf(
        "\n4. Bubble Sort"
    );


    printf(
        "\n\nSearching identifies the possible faulty part."
    );

    printf(
        "\nFiltering finds relevant parts and shops."
    );

    printf(
        "\nBubble Sort arranges parts by price."
    );

    printf(
        "\nBubble Sort arranges shops by distance."
    );


    printf(
        "\n\n========================================\n"
    );

    printf(
        "             PROGRAM END\n"
    );

    printf(
        "========================================\n\n"
    );


    return 0;

}

