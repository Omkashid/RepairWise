
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();

const PORT = 3000;


// ========================================
// MIDDLEWARE
// ========================================

app.use(cors());
app.use(express.json());


// ========================================
// HOME ROUTE
// ========================================

app.get("/", (req, res) => {

    res.json({
        success: true,
        message: "RepairWise backend is running!"
    });

});


// ========================================
// HEALTH CHECK
// ========================================

app.get("/api/health", (req, res) => {

    res.json({
        status: "online",
        service: "RepairWise"
    });

});


// ========================================
// DEVICE DATABASE API
// ========================================

app.get("/api/devices", (req, res) => {

    try {

        const filePath = path.join(
            __dirname,
            "..",
            "data",
            "devices.json"
        );

        const devices = JSON.parse(
            fs.readFileSync(filePath, "utf8")
        );

        res.json({

            success: true,

            count: devices.length,

            data: devices

        });

    }

    catch (error) {

        console.error(error);

        res.status(500).json({

            success: false,

            message:
                "Could not load device database."

        });

    }

});


// ========================================
// START SERVER
// ========================================

app.listen(PORT, () => {

    console.log("=================================");
    console.log("       RepairWise Backend");
    console.log("=================================");

    console.log(
        `Server running on http://localhost:${PORT}`
    );

});
