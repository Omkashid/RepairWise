
async function analyzeProblem() {

    const problem =
        document.getElementById("problem").value
            .toLowerCase()
            .trim();

    const selectedDevice =
        document.getElementById("device").value
            .toLowerCase()
            .trim();

    const selectedModel =
        document.getElementById("model").value
            .toLowerCase()
            .trim();

    const resultBox =
        document.getElementById("result");


    // ==========================================
    // CHECK INPUT
    // ==========================================

    if (problem === "") {

        alert("Please describe your problem first.");

        return;
    }


    // ==========================================
    // LOADING SCREEN
    // ==========================================

    resultBox.innerHTML = `

        <div class="analysis-loading">

            <div class="loader"></div>

            <h2>🧠 Analyzing Device...</h2>

            <p id="analysisStatus">
                Reading problem description...
            </p>

        </div>

    `;


    await wait(600);

    document.getElementById("analysisStatus").innerText =
        "🔍 Connecting to RepairWise backend...";


    await wait(600);

    document.getElementById("analysisStatus").innerText =
        "🧩 Understanding your problem...";


    await wait(600);

    document.getElementById("analysisStatus").innerText =
        "🔎 Searching possible faults...";


    await wait(600);

    document.getElementById("analysisStatus").innerText =
        "📊 Calculating repairability score...";


    await wait(600);


    try {

        // ==========================================
        // GET DIAGNOSIS DATABASE FROM BACKEND
        // ==========================================

        const deviceResponse =
            await fetch(
                "http://localhost:3000/api/devices"
            );


        if (!deviceResponse.ok) {

            throw new Error(
                "Backend could not be reached."
            );

        }


        const deviceResult =
            await deviceResponse.json();


        const devices =
            deviceResult.data;


        // ==========================================
        // GET PARTS
        // ==========================================

        const parts =
            await fetch("data/parts.json")
                .then(response => {

                    if (!response.ok) {

                        throw new Error(
                            "Parts database could not be loaded."
                        );

                    }

                    return response.json();

                });


        // ==========================================
        // GET SHOPS
        // ==========================================

        const shops =
            await fetch("data/shops.json")
                .then(response => {

                    if (!response.ok) {

                        throw new Error(
                            "Shop database could not be loaded."
                        );

                    }

                    return response.json();

                });


        // ==========================================
        // NORMALIZE USER PROBLEM
        // ==========================================

        const normalizedProblem =
            problem
                .replace(/[.,!?]/g, " ")
                .replace(/\s+/g, " ")
                .trim();


        // ==========================================
        // PROBLEM PATTERNS
        // ==========================================

        const problemPatterns = {

            screen: [
                "screen",
                "display",
                "black screen",
                "screen black",
                "screen is black",
                "display is black",
                "display black",
                "screen not working",
                "display not working",
                "screen gone black",
                "screen turned black",
                "nothing showing",
                "nothing is showing",
                "screen not turning on",
                "display not turning on"
            ],

            charging: [
                "charging",
                "charge",
                "not charging",
                "does not charge",
                "doesn't charge",
                "wont charge",
                "won't charge",
                "not taking charge",
                "not taking a charge",
                "charging stopped",
                "charging has stopped",
                "charger not working",
                "charging port"
            ],

            battery: [
                "battery",
                "draining",
                "battery draining",
                "battery drains",
                "battery dying",
                "dies quickly",
                "dies fast",
                "losing battery",
                "battery life",
                "low battery",
                "battery backup",
                "battery backup is low"
            ],

            speaker: [
                "speaker",
                "sound",
                "audio",
                "no sound",
                "no audio",
                "sound not working",
                "speaker not working",
                "speaker stopped",
                "cannot hear",
                "can't hear",
                "nothing can be heard",
                "one side",
                "one side not working",
                "left side not working",
                "right side not working"
            ],

            camera: [
                "camera",
                "camera not working",
                "camera stopped",
                "camera doesn't work",
                "camera does not work",
                "cannot take photos",
                "can't take photos",
                "not taking photos",
                "photos not working",
                "photo problem",
                "focus",
                "focusing",
                "not focusing",
                "camera not focusing"
            ],

            keyboard: [
                "keyboard",
                "keyboard not working",
                "keys",
                "key not working",
                "some keys not working",
                "keyboard stopped",
                "cannot type",
                "can't type",
                "typing problem"
            ],

            touch: [
                "touch",
                "touchscreen",
                "touch screen",
                "touch not working",
                "touch stopped",
                "screen touch",
                "cannot touch",
                "can't touch"
            ],

            flash: [
                "flash",
                "flash not working",
                "flash stopped",
                "camera flash",
                "flash problem"
            ]

        };


        // ==========================================
        // DETECT PROBLEM CATEGORY
        // ==========================================

        let detectedCategories = [];


        for (
            const category in problemPatterns
        ) {

            const patterns =
                problemPatterns[category];


            for (
                let i = 0;
                i < patterns.length;
                i++
            ) {

                if (
                    normalizedProblem.includes(
                        patterns[i]
                    )
                ) {

                    detectedCategories.push(
                        category
                    );

                    break;

                }

            }

        }


        // ==========================================
        // FIND BEST DIAGNOSIS
        // ==========================================

        let diagnosis = null;

        let bestScore = 0;


        devices.forEach(function(item) {

            const databaseDevice =
                item.device
                    .toLowerCase();

            const databaseModel =
                item.model
                    .toLowerCase();

            const databaseProblem =
                item.problem
                    .toLowerCase();


            // Device must match

            if (
                databaseDevice !==
                selectedDevice
            ) {

                return;

            }


            // Model must match

            if (
                databaseModel !==
                selectedModel
            ) {

                return;

            }


            let score = 0;


            // Exact phrase match

            if (
                normalizedProblem.includes(
                    databaseProblem
                )
            ) {

                score += 100;

            }


            // Reverse phrase match

            if (
                databaseProblem.includes(
                    normalizedProblem
                )
            ) {

                score += 80;

            }


            // Category matching

            let category = null;


            if (
                databaseProblem.includes("screen") ||
                databaseProblem.includes("display")
            ) {

                category = "screen";

            }

            else if (
                databaseProblem.includes("charging") ||
                databaseProblem.includes("charge")
            ) {

                category = "charging";

            }

            else if (
                databaseProblem.includes("battery") ||
                databaseProblem.includes("draining")
            ) {

                category = "battery";

            }

            else if (
                databaseProblem.includes("speaker") ||
                databaseProblem.includes("sound")
            ) {

                category = "speaker";

            }

            else if (
                databaseProblem.includes("camera") ||
                databaseProblem.includes("focus")
            ) {

                category = "camera";

            }

            else if (
                databaseProblem.includes("keyboard")
            ) {

                category = "keyboard";

            }

            else if (
                databaseProblem.includes("touch")
            ) {

                category = "touch";

            }

            else if (
                databaseProblem.includes("flash")
            ) {

                category = "flash";

            }


            if (
                category &&
                detectedCategories.includes(category)
            ) {

                score += 50;

            }


            // Word matching

            const databaseWords =
                databaseProblem
                    .split(" ");


            databaseWords.forEach(
                function(word) {

                    if (
                        word.length > 3 &&
                        normalizedProblem.includes(word)
                    ) {

                        score += 5;

                    }

                }
            );


            // Keep highest scoring result

            if (score > bestScore) {

                bestScore = score;

                diagnosis = item;

            }

        });


        // ==========================================
        // NO MATCH
        // ==========================================

        if (!diagnosis) {

            resultBox.innerHTML = `

                <div class="error-result">

                    <h2>
                        ❌ Unable to Identify Problem
                    </h2>

                    <p>
                        RepairWise could not find a
                        suitable match for your description.
                    </p>

                    <p>
                        Try describing symptoms such as
                        "screen is black", "not charging",
                        "battery draining quickly",
                        "speaker not working", or
                        "camera not focusing".
                    </p>

                </div>

            `;

            return;

        }


        // ==========================================
        // FIND MATCHING PARTS
        // ==========================================

        let matchingParts =
            parts.filter(function(part) {

                return (

                    part.device
                        .toLowerCase() ===
                    selectedDevice &&

                    part.part
                        .toLowerCase() ===
                    diagnosis.part
                        .toLowerCase()

                );

            });


        // ==========================================
        // SORT PARTS BY PRICE
        // ==========================================

        matchingParts.sort(function(a, b) {

            return a.price - b.price;

        });


        // ==========================================
        // FIND MATCHING SHOPS
        // ==========================================

        let matchingShops =
            shops.filter(function(shop) {

                return shop.service
                    .toLowerCase()
                    .includes(selectedDevice);

            });


        // ==========================================
        // SORT SHOPS BY DISTANCE
        // ==========================================

        matchingShops.sort(function(a, b) {

            return a.distance - b.distance;

        });


        // ==========================================
        // PART HTML
        // ==========================================

        let partsHTML = "";


        if (matchingParts.length === 0) {

            partsHTML = `

                <div class="error-result">

                    <p>
                        No sample spare-part data is
                        available for this component.
                    </p>

                </div>

            `;

        }

        else {

            matchingParts.forEach(
                function(part, index) {

                    partsHTML += `

                        <div class="part">

                            <h3>

                                🔧 ${part.part}

                                ${
                                    index === 0
                                    ? " ⭐ Best Price"
                                    : ""
                                }

                            </h3>

                            <p>

                                <strong>
                                    Seller:
                                </strong>

                                ${part.seller}

                            </p>

                            <p>

                                <strong>
                                    Price:
                                </strong>

                                ₹${part.price.toLocaleString(
                                    "en-IN"
                                )}

                            </p>

                            <p>

                                <strong>
                                    Availability:
                                </strong>

                                ${part.availability}

                            </p>

                        </div>

                    `;

                }
            );

        }


        // ==========================================
        // SHOP HTML
        // ==========================================

        let shopsHTML = "";


        if (matchingShops.length === 0) {

            shopsHTML = `

                <div class="error-result">

                    <p>
                        No sample repair-shop data is
                        available for this device.
                    </p>

                </div>

            `;

        }

        else {

            matchingShops.forEach(
                function(shop, index) {

                    shopsHTML += `

                        <div class="shop">

                            <h3>

                                📍 ${shop.name}

                                ${
                                    index === 0
                                    ? " ⭐ Nearest"
                                    : ""
                                }

                            </h3>

                            <p>

                                <strong>
                                    Location:
                                </strong>

                                ${shop.location}

                            </p>

                            <p>

                                <strong>
                                    Distance:
                                </strong>

                                ${shop.distance} km

                            </p>

                            <p>

                                <strong>
                                    Service:
                                </strong>

                                ${shop.service}

                            </p>

                        </div>

                    `;

                }
            );

        }


        // ==========================================
        // DISPLAY RESULT
        // ==========================================

        resultBox.innerHTML = `

            <div class="success-result">

                <div class="success-icon">
                    ✓
                </div>

                <h2>
                    Analysis Complete
                </h2>

                <p>
                    RepairWise identified a possible
                    issue from your description.
                </p>

            </div>


            <h2>
                🔍 Analysis Result
            </h2>


            <p>

                <strong>
                    Device:
                </strong>

                ${diagnosis.device}

            </p>


            <p>

                <strong>
                    Model:
                </strong>

                ${diagnosis.model}

            </p>


            <p>

                <strong>
                    Possible Issue:
                </strong>

                ${diagnosis.problem}

            </p>


            <p>

                <strong>
                    Possible Faulty Part:
                </strong>

                ${diagnosis.part}

            </p>


            <!-- REPAIRABILITY -->

            <div class="repair-score">

                <div class="score-header">

                    <strong>
                        🔧 Repairability Score
                    </strong>

                    <span class="score-number">

                        ${diagnosis.repairability}/100

                    </span>

                </div>


                <div class="progress-container">

                    <div
                        class="progress-bar"
                        id="repairProgress">
                    </div>

                </div>


                <p>

                    Higher score means the device is
                    generally easier to repair.

                </p>

            </div>


            <!-- SPARE PARTS -->

            <h2>
                🛠️ Spare Parts
            </h2>

            ${partsHTML}


            <!-- PRICE COMPARISON -->

            <div class="dsa-box">

                <h3>
                    💰 Price Comparison
                </h3>

                <p>

                    Spare parts are sorted from
                    <strong>
                        lowest to highest price
                    </strong>.

                </p>


                ${
                    matchingParts.length > 0
                    ? `

                        <p>

                            <strong>
                                Lowest Price:
                            </strong>

                            ₹${matchingParts[0].price.toLocaleString(
                                "en-IN"
                            )}

                        </p>

                    `
                    : ""
                }

            </div>


            <!-- SHOPS -->

            <h2>
                📍 Nearby Repair Shops
            </h2>

            <p>
                <small>
                    Sample project data — not real-time
                    store information.
                </small>
            </p>

            ${shopsHTML}


            <!-- DSA -->

            <div class="dsa-box">

                <h3>
                    🧠 DSA Used in This Project
                </h3>


                <p>

                    <strong>
                        1. Searching:
                    </strong>

                    Searches the device database to
                    identify a possible faulty component.

                </p>


                <p>

                    <strong>
                        2. Filtering:
                    </strong>

                    Filters relevant spare parts and
                    repair shops.

                </p>


                <p>

                    <strong>
                        3. Sorting:
                    </strong>

                    Sorts spare parts by price and
                    repair shops by distance.

                </p>


                <p>

                    <strong>
                        4. Arrays:
                    </strong>

                    Stores device, part and shop
                    information.

                </p>

            </div>


            <!-- WARNING -->

            <div class="warning-box">

                <strong>
                    ⚠️ Important:
                </strong>


                <p>

                    This system provides a possible issue
                    based on the problem description.
                    It is not a professional diagnosis.

                </p>


                <p>

                    Get the device inspected by a
                    qualified technician before purchasing
                    or replacing any component.

                </p>

            </div>


            <!-- 3D -->

            <button
                class="visualize-button"
                onclick="open3DVisualization(
                    '${diagnosis.part}',
                    '${diagnosis.device}'
                )">

                🔬 View 3D Repair Visualization

            </button>

        `;


        // ==========================================
        // ANIMATE SCORE
        // ==========================================

        setTimeout(function() {

            const progress =
                document.getElementById(
                    "repairProgress"
                );


            if (progress) {

                progress.style.width =
                    diagnosis.repairability + "%";

            }

        }, 100);

    }


    // ==========================================
    // ERROR
    // ==========================================

    catch (error) {

        console.error(error);


        resultBox.innerHTML = `

            <div class="error-result">

                <h2>
                    ⚠️ Connection Error
                </h2>


                <p>

                    RepairWise could not connect to
                    the backend server.

                </p>


                <p>

                    Make sure the backend is running:

                </p>


                <p>

                    <strong>
                        node server.js
                    </strong>

                </p>


                <p>

                    Backend:

                    <strong>
                        http://localhost:3000
                    </strong>

                </p>

            </div>

        `;

    }

}


// ==========================================
// WAIT
// ==========================================

function wait(milliseconds) {

    return new Promise(function(resolve) {

        setTimeout(resolve, milliseconds);

    });

}


// ==========================================
// 3D VISUALIZATION
// ==========================================

function open3DVisualization(part, device) {

    localStorage.setItem(
        "faultyPart",
        part
    );


    localStorage.setItem(
        "selectedDevice",
        device
    );


    window.location.href =
        "3d-phone.html";

}
